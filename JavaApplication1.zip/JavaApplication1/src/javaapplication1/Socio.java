package javaapplication1;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author alunodev08
 */
public class Socio {
    int id;
    String nome;
    
    //Dependente d;
    
    List<Dependente> listaDep;
    
    public Socio() {
    listaDep = new ArrayList<>();
}
    
    void adicionar(Dependente d){
        listaDep.add(d);
    }
    
    Dependente buscar(Dependente d){
        return listaDep.get(listaDep.indexOf(d));
    }
}
