/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication1;

/**
 *
 * @author alunodev08
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Socio sc = new Socio();
        sc.nome = "Vinicius";
        sc.id = 1;
        
        Dependente dp01 = new Dependente();
        dp01.nome = "Rosalen";
        dp01.idade = 20;
        
        //sc.d = dp01;
        sc.adicionar(dp01);
        System.out.print("Qual eh a idade do dependente do Rosalen: ");
        //System.out.println(sc.d.idade);
        System.out.println(sc.buscar(dp01).idade);
    }
    
}
