/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ecomerce.uvv;


/**
 *
 * @author alunodev10
 */
public class itempedido {
    private int itemPedidoId, quantidade;
    private String item;
    private float Precounitario;
    
    float calcularPrecoTotal;
    
    itempedido ip = new itempedido();
    
    
}
