/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ecomerce.uvv;

import java.util.Date;

/**
 *
 * @author alunodev10
 */
public class pedido {
    private int PedidoId;
    private Date dataEmissao;
    private float valorTotalCalculado;
    
//     pedido p = new pedido();
     
}
