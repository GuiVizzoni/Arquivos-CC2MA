/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ecomerce.uvv;

import java.util.List;

/**
 *
 * @author alunodev10
 */
public class loja {
    private int lojaid;
    private String nomeFantasia, cnpj;
    private double ValorDeMercado;
    
    List<pedido> p;

    public loja(int lojaid, String nomeFantasia, String cnpj, double ValorDeMercado, List<pedido> p) {
        this.lojaid = lojaid;
        this.nomeFantasia = nomeFantasia;
        this.cnpj = cnpj;
        this.ValorDeMercado = ValorDeMercado;
        this.p = p;
    
    //List<itempedido> ip;
   
   
    }
public static void main(String[] args) {
    //p.setedidoId;
//System.out.println("insira o id do pedido:" + );
    
    
    
    
    
}
    
    
    
    
}

