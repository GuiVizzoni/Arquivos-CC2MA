/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ecomerce.uvv;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author alunodev10
 */
public class EcomerceUVV {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //pedido p = new pedido();
        Scanner sc = new Scanner(System.in);
        List<pedido> PedidoId = new ArrayList<>();
        PedidoId.add("teste");
        
        System.out.println("Insira o pedido: ");
        int lojaid = sc.nextInt;
        
        //p.getpedidoid();
        lojaid li = new lojaid();
        li.set
    }
    
}
