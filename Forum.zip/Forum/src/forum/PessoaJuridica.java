/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package forum;

public class PessoaJuridica extends Pessoa{
    long cnpj;
    String razaoSocial;
    String nomeRepresentante;
    
   void exibirDados(){
     System.out.println("Teste ze" + cnpj + razaoSocial + nomeRepresentante);
    }
}
