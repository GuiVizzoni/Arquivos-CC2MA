/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package zoo;

/**
 *
 * @author alunodev08
 */
public class Animal extends SerVivo {
    String sexo;
    int numeroPatas;
    
    void respirar(){
        System.out.println("Animal: respirar()");
    }
    void mover(){
        System.out.println("Animal: mover()");
    }
    
    
}
