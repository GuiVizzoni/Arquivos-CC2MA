/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package zoo;

/**
 *
 * @author alunodev08
 */
public class UsaZoo {
    
    public static void main(String[] args) {
        System.out.println("===Ser Vivo===");
        SerVivo sv = new SerVivo();
        sv.nascer();
        sv.crescer();
        sv.morrer();
        
        System.out.println("\n===Animal===");
        Animal an = new Animal();
        an.sexo = "M";
        an.numeroPatas = 4;
        an.respirar();
        an.mover();
        an.nascer();
        an.crescer();
        an.morrer();
        
       System.out.println("\n===Mamifero===");
        Mamifero ma = new Mamifero();
        ma.mover();
        ma.nascer();
        ma.respirar();
        
        
        System.out.println("\n===Peixe===");
        Peixe px = new Peixe();
        px.nascer();
        px.mover();
        px.respirar();
        
    }
    
}
